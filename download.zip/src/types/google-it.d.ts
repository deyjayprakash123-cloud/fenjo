declare module 'google-it' {
  interface GoogleItOptions {
    query: string;
    limit?: number;
    disableConsole?: boolean;
    includeSites?: string | string[];
    excludeSites?: string | string[];
  }

  interface GoogleItResult {
    title: string;
    link: string;
    snippet: string;
    isFromGoogle?: boolean;
  }

  function google(options: GoogleItOptions): Promise<GoogleItResult[]>;

  export = google;
}
