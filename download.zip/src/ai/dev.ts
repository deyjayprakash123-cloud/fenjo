import { config } from 'dotenv';
config();

import '@/ai/flows/summarize-job-description.ts';
import '@/ai/flows/generate-career-suggestions.ts';
import '@/ai/flows/generate-guide.ts';
import '@/ai/flows/finjo-buddy.ts';
import '@/ai/flows/get-news.ts';
import '@/ai/flows/generate-image.ts';
import '@/ai/tools/search.ts';
