import { BrainCircuit } from 'lucide-react';
import { cn } from '@/lib/utils';

type FinjoLogoProps = {
  className?: string;
};

export function FinjoLogo({ className }: FinjoLogoProps) {
  return (
    <div
      className={cn(
        'bg-primary text-primary-foreground p-3 rounded-lg flex items-center justify-center shadow-md shadow-primary/30',
        className
      )}
    >
      <BrainCircuit className="w-6 h-6" />
    </div>
  );
}
